﻿using PedidoDao;
using System.Data;

namespace PedidoLib
{
    public class ControladorPedidoCompleto
    {
        private Contexto contexto;

        public ControladorPedidoCompleto()
        {
            contexto = new Contexto();
        }

        // Métodos CRUD para Pedidos
        public DataTable ObtenerPedidos()
        {
            return contexto.GetPedidos();
        }

        public DataTable ObtenerClientes()
        {
            return contexto.GetClientes();
        }

        public DataTable ObtenerMenus()
        {
            return contexto.ObtenerMenus();
        }

        public void AddPedido(int clienteID, DateTime fechaPedido, decimal total)
        {
            contexto.AddPedido(clienteID, fechaPedido, total);
        }

        public void UpdatePedido(int pedidoID, int clienteID, DateTime fechaPedido, decimal total)
        {
            contexto.UpdatePedido(pedidoID, clienteID, fechaPedido, total);
        }

        public void EliminarPedido(int pedidoID)
        {
            contexto.DeletePedido(pedidoID);
        }

        public DataTable ObtenerPedidoPorId(int pedidoID)
        {
            return contexto.GetPedidoById(pedidoID);
        }

        public int ObtenerSiguienteIdDisponible()
        {
            DataTable pedidos = contexto.GetPedidos();
            if (pedidos.Rows.Count == 0)
                return 1;

            return pedidos.AsEnumerable().Max(row => row.Field<int>("PedidoID")) + 1;
        }

        // Métodos CRUD para DetallesPedido
        public DataTable ObtenerDetallesPedido(int pedidoID)
        {
            return contexto.GetDetallesPedidoByPedidoId(pedidoID);
        }

        public void AddDetallePedido(int pedidoID, int menuID, int cantidad, decimal precio)
        {
            contexto.AddDetallePedido(pedidoID, menuID, cantidad, precio);
        }

        public void EliminarDetallePedido(int pedidoID, int menuID)
        {
            contexto.DeleteDetallePedido(pedidoID, menuID);
        }

        // Método para actualizar un detalle del pedido
        public void UpdateDetallePedido(int detalleID, int pedidoID, int menuID, int cantidad, decimal precio)
        {
            contexto.UpdateDetallePedido(detalleID, pedidoID, menuID, cantidad, precio);
        }

        // Método para reducir la cantidad de ingredientes
        public void ReducirCantidadIngredientes(int menuID)
        {
            contexto.ReducirCantidadIngredientes(menuID);
        }
    }
}

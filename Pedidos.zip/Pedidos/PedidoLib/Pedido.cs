﻿namespace PedidoLib
{
    public class Pedido
    {
        public int PedidoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime FechaPedido { get; set; }
        public decimal Total { get; set; }

        public Pedido()
        {
            PedidoID = 0;
            ClienteID = 0;
            FechaPedido = DateTime.MinValue;
            Total = 0.0M;
        }

        public Pedido(int pedidoID, int clienteID, DateTime fechaPedido, decimal total)
        {
            PedidoID = pedidoID;
            ClienteID = clienteID;
            FechaPedido = fechaPedido;
            Total = total;
        }
    }

    public class DetallePedido
    {
        public int DetalleID { get; set; }
        public int PedidoID { get; set; }
        public int MenuID { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }

        public DetallePedido()
        {
            DetalleID = 0;
            PedidoID = 0;
            MenuID = 0;
            Cantidad = 0;
            Precio = 0.0M;
        }

        public DetallePedido(int detalleID, int pedidoID, int menuID, int cantidad, decimal precio)
        {
            DetalleID = detalleID;
            PedidoID = pedidoID;
            MenuID = menuID;
            Cantidad = cantidad;
            Precio = precio;
        }
    }
}

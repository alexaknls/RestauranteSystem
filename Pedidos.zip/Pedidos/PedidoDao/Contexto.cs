﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace PedidoDao
{
    public class Contexto
    {
        private string connectionString = @"Data Source=LAPTOP-D5BUJAN7\SQLEXPRESS;Initial Catalog=Restaurante_Gourmet;Integrated Security=True;Encrypt=False";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public DataTable GetMenus()
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Menu", con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable menusTable = new DataTable();
                adapter.Fill(menusTable);
                return menusTable;
            }
        }

        // Métodos para Pedidos
        public DataTable GetPedidos()
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Pedidos", con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable pedidosTable = new DataTable();
                adapter.Fill(pedidosTable);
                return pedidosTable;
            }
        }

        public DataTable GetDetallesPedidoByPedidoId(int pedidoID)
        {
            DataTable dtDetalles = new DataTable();
            using (var connection = new SqlConnection(connectionString))
            {
                string query = "SELECT DetalleID, MenuID, Cantidad, Precio FROM DetallesPedido WHERE PedidoID = @PedidoID";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PedidoID", pedidoID);
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dtDetalles);
                    }
                }
            }
            return dtDetalles;
        }

        public DataTable ObtenerMenus()
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    @"SELECT DISTINCT m.MenuID, m.Nombre, CAST(m.Descripcion AS NVARCHAR(MAX)) AS Descripcion, m.Precio
              FROM Menu m
              WHERE NOT EXISTS (
                  SELECT 1
                  FROM TIngredientes ti
                  INNER JOIN Productos p ON ti.ProductoID = p.ProductoID
                  WHERE ti.MenuID = m.MenuID AND p.Estado = 'Inactivo'
              )", con);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public void AddPedido(int clienteID, DateTime fechaPedido, decimal total)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO Pedidos (ClienteID, FechaPedido, Total, Estado) VALUES (@ClienteID, @FechaPedido, @Total, 'Confirmado')", con, transaction);
                        cmd.Parameters.AddWithValue("@ClienteID", clienteID);
                        cmd.Parameters.AddWithValue("@FechaPedido", fechaPedido);
                        cmd.Parameters.AddWithValue("@Total", total);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        public void UpdatePedido(int pedidoID, int clienteID, DateTime fechaPedido, decimal total)
        {
            if (IsPedidoConfirmed(pedidoID))
            {
                throw new Exception("No se puede modificar un pedido confirmado.");
            }

            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE Pedidos SET ClienteID = @ClienteID, FechaPedido = @FechaPedido, Total = @Total WHERE PedidoID = @PedidoID", con, transaction);
                        cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                        cmd.Parameters.AddWithValue("@ClienteID", clienteID);
                        cmd.Parameters.AddWithValue("@FechaPedido", fechaPedido);
                        cmd.Parameters.AddWithValue("@Total", total);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        private bool IsPedidoConfirmed(int pedidoID)
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT Estado FROM Pedidos WHERE PedidoID = @PedidoID", con);
                cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                con.Open();
                string estado = cmd.ExecuteScalar().ToString();
                con.Close();
                return estado == "Confirmado";
            }
        }

        public void DeletePedido(int pedidoID)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        // Primero, obtenemos los productos y las cantidades del pedido para actualizar el inventario
                        SqlCommand getProductsCmd = new SqlCommand(
                            @"SELECT p.ProductoID, ti.Cantidad * dp.Cantidad AS Cantidad
                      FROM DetallesPedido dp
                      INNER JOIN TIngredientes ti ON dp.MenuID = ti.MenuID
                      INNER JOIN Productos p ON ti.ProductoID = p.ProductoID
                      WHERE dp.PedidoID = @PedidoID", con, transaction);
                        getProductsCmd.Parameters.AddWithValue("@PedidoID", pedidoID);

                        SqlDataReader reader = getProductsCmd.ExecuteReader();
                        Dictionary<int, int> productos = new Dictionary<int, int>();

                        while (reader.Read())
                        {
                            int productoID = reader.GetInt32(0);
                            int cantidad = reader.GetInt32(1);

                            if (productos.ContainsKey(productoID))
                            {
                                productos[productoID] += cantidad;
                            }
                            else
                            {
                                productos.Add(productoID, cantidad);
                            }
                        }
                        reader.Close();

                        // Actualizamos el inventario de productos
                        foreach (var item in productos)
                        {
                            SqlCommand updateStockCmd = new SqlCommand(
                                "UPDATE Productos SET Cantidad = Cantidad + @Cantidad WHERE ProductoID = @ProductoID", con, transaction);
                            updateStockCmd.Parameters.AddWithValue("@Cantidad", item.Value);
                            updateStockCmd.Parameters.AddWithValue("@ProductoID", item.Key);

                            updateStockCmd.ExecuteNonQuery();
                        }

                        // Borramos los detalles del pedido
                        SqlCommand deleteDetailsCmd = new SqlCommand("DELETE FROM DetallesPedido WHERE PedidoID = @PedidoID", con, transaction);
                        deleteDetailsCmd.Parameters.AddWithValue("@PedidoID", pedidoID);

                        deleteDetailsCmd.ExecuteNonQuery();

                        // Borramos el pedido
                        SqlCommand deletePedidoCmd = new SqlCommand("DELETE FROM Pedidos WHERE PedidoID = @PedidoID", con, transaction);
                        deletePedidoCmd.Parameters.AddWithValue("@PedidoID", pedidoID);

                        deletePedidoCmd.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        public DataTable GetPedidoById(int pedidoID)
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Pedidos WHERE PedidoID = @PedidoID", con);
                cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable pedidoTable = new DataTable();
                adapter.Fill(pedidoTable);
                return pedidoTable;
            }
        }

        // Métodos para DetallesPedido
        public DataTable GetDetallesPedido()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DetallesPedido";
                SqlCommand command = new SqlCommand(query, connection);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable detallesPedido = new DataTable();
                adapter.Fill(detallesPedido);

                return detallesPedido;
            }
        }

        public DataTable GetClientes()
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Clientes", con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable clientesTable = new DataTable();
                adapter.Fill(clientesTable);
                return clientesTable;
            }
        }

        public void AddDetallePedido(int pedidoID, int menuID, int cantidad, decimal precio)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO DetallesPedido (PedidoID, MenuID, Cantidad, Precio) VALUES (@PedidoID, @MenuID, @Cantidad, @Precio)", con, transaction);
                        cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                        cmd.Parameters.AddWithValue("@MenuID", menuID);
                        cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                        cmd.Parameters.AddWithValue("@Precio", precio);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        public void UpdateDetallePedido(int detalleID, int pedidoID, int menuID, int cantidad, decimal precio)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE DetallesPedido SET PedidoID = @PedidoID, MenuID = @MenuID, Cantidad = @Cantidad, Precio = @Precio WHERE DetalleID = @DetalleID", con, transaction);
                        cmd.Parameters.AddWithValue("@DetalleID", detalleID);
                        cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                        cmd.Parameters.AddWithValue("@MenuID", menuID);
                        cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                        cmd.Parameters.AddWithValue("@Precio", precio);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        public void DeleteDetallePedido(int pedidoID, int menuID)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("DELETE FROM DetallesPedido WHERE PedidoID = @PedidoID AND MenuID = @MenuID", con, transaction);
                        cmd.Parameters.AddWithValue("@PedidoID", pedidoID);
                        cmd.Parameters.AddWithValue("@MenuID", menuID);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }

        public void ReducirCantidadIngredientes(int menuID)
        {
            using (SqlConnection con = GetConnection())
            {
                con.Open();
                using (SqlTransaction transaction = con.BeginTransaction())
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand(
                            @"UPDATE p
                          SET p.Cantidad = p.Cantidad - ti.Cantidad
                          FROM Productos p
                          INNER JOIN TIngredientes ti ON p.ProductoID = ti.ProductoID
                          WHERE ti.MenuID = @MenuID", con, transaction);
                        cmd.Parameters.AddWithValue("@MenuID", menuID);

                        cmd.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
                con.Close();
            }
        }
    }
}
